"""
meta attributes for packaging which does not import any dependencies
"""
__version__ = '3.4.0'
__author__ = 'python-ldap project'
__license__ = 'Python style'
